package com.proyecto.escapaditas.jms;


import com.proyecto.escapaditas.entidades.Promocion;
import com.proyecto.escapaditas.negocio.Negocio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JmsOyente {

    @Autowired
    private Negocio negocio;

    @JmsListener(destination="${jms.destino}")
    public void miMensaje(String mensajeJson) {
        System.out.println("Recibido:" + mensajeJson);
        //mensajeJSON a Objeto Auto
        ObjectMapper mapper = new ObjectMapper();
        try {
            Promocion promocion =  mapper.readValue(mensajeJson, Promocion.class);
            promocion.setRespuesta("Registrar a Tabla");
            System.out.println(mensajeJson);
            Promocion respuesta = negocio.registrarPromocion( "72647278", promocion);//registra en la base de  datos
            if (respuesta==null) {
                System.out.println("No se pudo registrar");
            }
            else {
                System.out.println("Registrado ok!");
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
            System.out.println("No se pudo registrar");
        }
    }

}