package com.proyecto.escapaditas.repositorios;


import com.proyecto.escapaditas.entidades.Pago;
import org.springframework.data.repository.CrudRepository;

public interface PagoRepositorio extends CrudRepository<Pago, Long> {
}
